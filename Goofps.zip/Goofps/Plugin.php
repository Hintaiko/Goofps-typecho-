<?php

/**
 * 在网站左上角显示实时帧数
 *
 * @package Goofps
 * @version 1.0
 * @author Hinataiko
 */

namespace TypechoPlugin\Goofps;

use Typecho\Plugin\PluginInterface;
use Typecho\Widget\Helper\Form;
use Typecho\Widget\Helper\Form\Element\Select;
use Typecho\Widget\Helper\Form\Element\Text;
use Widget\Options;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Plugin implements PluginInterface
{
    public static function activate()
    {
        \Typecho\Plugin::factory('Widget\Archive')->header =
            [__CLASS__, 'renderHeader'];

        \Typecho\Plugin::factory('Widget\Archive')->footer =
            [__CLASS__, 'renderFooter'];

        return _t('Goofps 插件已启用');
    }

    public static function deactivate()
    {
        return _t('Goofps 插件已停用');
    }

    public static function config(Form $form)
    {
        $accent = new Select(
            'accent',
            [
                'pink'   => _t('素粉'),
                'blue'   => _t('浅蓝'),
                'green'  => _t('浅绿'),
                'purple' => _t('浅紫'),
                'orange' => _t('暖橙'),
                'theme'  => _t('跟随主题强调色'),
            ],
            'pink',
            _t('FPS 颜色'),
            _t('控制文字、状态点和边框颜色。')
        );
        $form->addInput($accent);

        $background = new Select(
            'background',
            [
                'theme'       => _t('跟随网站背景'),
                'pink'        => _t('淡粉背景'),
                'blue'        => _t('淡蓝背景'),
                'green'       => _t('淡绿背景'),
                'neutral'     => _t('半透明中性背景'),
                'transparent' => _t('高透明背景'),
            ],
            'theme',
            _t('背景颜色'),
            _t('浅色和深色模式会自动使用对应背景。')
        );
        $form->addInput($background);

        $fontSize = new Text(
            'fontSize',
            null,
            '13',
            _t('电脑端字号'),
            _t('单位为 px，建议填写 11 到 18。')
        );
        $fontSize->input->setAttribute('type', 'number');
        $fontSize->input->setAttribute('min', '9');
        $fontSize->input->setAttribute('max', '30');
        $form->addInput($fontSize);

        $mobileFontSize = new Text(
            'mobileFontSize',
            null,
            '11',
            _t('手机端字号'),
            _t('单位为 px，建议填写 10 到 16。')
        );
        $mobileFontSize->input->setAttribute('type', 'number');
        $mobileFontSize->input->setAttribute('min', '9');
        $mobileFontSize->input->setAttribute('max', '24');
        $form->addInput($mobileFontSize);

        $top = new Text(
            'top',
            null,
            '16',
            _t('顶部距离'),
            _t('单位为 px，只填写数字。')
        );
        $top->input->setAttribute('type', 'number');
        $top->input->setAttribute('min', '0');
        $top->input->setAttribute('max', '500');
        $form->addInput($top);

        $left = new Text(
            'left',
            null,
            '16',
            _t('左侧距离'),
            _t('单位为 px，只填写数字。')
        );
        $left->input->setAttribute('type', 'number');
        $left->input->setAttribute('min', '0');
        $left->input->setAttribute('max', '500');
        $form->addInput($left);

        $radius = new Text(
            'radius',
            null,
            '10',
            _t('边框圆角'),
            _t('单位为 px，填写 0 表示直角。')
        );
        $radius->input->setAttribute('type', 'number');
        $radius->input->setAttribute('min', '0');
        $radius->input->setAttribute('max', '50');
        $form->addInput($radius);

        $shadow = new Select(
            'shadow',
            [
                'on'  => _t('显示'),
                'off' => _t('隐藏'),
            ],
            'on',
            _t('阴影')
        );
        $form->addInput($shadow);

        $showDot = new Select(
            'showDot',
            [
                'on'  => _t('显示'),
                'off' => _t('隐藏'),
            ],
            'on',
            _t('状态点')
        );
        $form->addInput($showDot);

        $updateInterval = new Select(
            'updateInterval',
            [
                '250'  => _t('0.25 秒'),
                '500'  => _t('0.5 秒'),
                '1000' => _t('1 秒'),
            ],
            '500',
            _t('刷新频率'),
            _t('只影响数字更新速度，不影响 FPS 统计准确性。')
        );
        $form->addInput($updateInterval);
    }

    public static function personalConfig(Form $form)
    {
    }

    public static function renderHeader($archive = null)
    {
        $config = self::getConfig();

        $accent = self::option($config, 'accent', 'pink');
        $background = self::option($config, 'background', 'theme');

        $accentColors = self::getAccentColors($accent);
        $backgroundColors = self::getBackgroundColors($background);

        $fontSize = self::number(
            self::option($config, 'fontSize', '13'),
            9,
            30,
            13
        );

        $mobileFontSize = self::number(
            self::option($config, 'mobileFontSize', '11'),
            9,
            24,
            11
        );

        $top = self::number(
            self::option($config, 'top', '16'),
            0,
            500,
            16
        );

        $left = self::number(
            self::option($config, 'left', '16'),
            0,
            500,
            16
        );

        $radius = self::number(
            self::option($config, 'radius', '10'),
            0,
            50,
            10
        );

        $shadowEnabled =
            self::option($config, 'shadow', 'on') === 'on';

        $lightAccent = $accentColors[0];
        $darkAccent = $accentColors[1];
        $lightBackground = $backgroundColors[0];
        $darkBackground = $backgroundColors[1];

        $lightShadow = $shadowEnabled
            ? '0 5px 18px rgba(0, 0, 0, .10)'
            : 'none';

        $darkShadow = $shadowEnabled
            ? '0 5px 20px rgba(0, 0, 0, .32)'
            : 'none';

        echo <<<CSS
<style id="goofps-style">
    #goofps {
        --goofps-accent: {$lightAccent};
        --goofps-background: {$lightBackground};

        position: fixed;
        z-index: 2147483000;
        top: calc({$top}px + env(safe-area-inset-top, 0px));
        left: calc({$left}px + env(safe-area-inset-left, 0px));

        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 6px;

        min-width: 66px;
        min-height: 30px;
        max-width: calc(100vw - 24px);
        padding: 5px 10px;

        color: var(--goofps-accent);
        background-color: var(--goofps-background);
        border: 1px solid var(--goofps-accent);
        border-radius: {$radius}px;
        box-shadow: {$lightShadow};

        -webkit-backdrop-filter: blur(10px) saturate(120%);
        backdrop-filter: blur(10px) saturate(120%);

        font-family: inherit;
        font-size: {$fontSize}px;
        font-weight: 600;
        font-style: normal;
        line-height: 1.2;
        letter-spacing: 0;
        font-variant-numeric: tabular-nums;
        white-space: nowrap;
        text-align: center;

        pointer-events: none;
        user-select: none;
        overflow: hidden;
        contain: layout style paint;

        transition:
            color .3s ease,
            background-color .3s ease,
            border-color .3s ease,
            box-shadow .3s ease;
    }

    #goofps .goofps-dot {
        width: 6px;
        height: 6px;
        flex: 0 0 6px;
        border-radius: 50%;
        background-color: currentColor;
        opacity: .9;
    }

    #goofps .goofps-label {
        opacity: .72;
        font-size: .84em;
        font-weight: 500;
    }

    #goofps .goofps-value {
        display: inline-block;
        min-width: 2.2ch;
        font-weight: 700;
        text-align: right;
    }

    html[data-theme="dark"] #goofps {
        --goofps-accent: {$darkAccent};
        --goofps-background: {$darkBackground};
        box-shadow: {$darkShadow};
    }

    @media (prefers-color-scheme: dark) {
        html:not([data-theme]) #goofps {
            --goofps-accent: {$darkAccent};
            --goofps-background: {$darkBackground};
            box-shadow: {$darkShadow};
        }
    }

    @media screen and (max-width: 579px) {
        #goofps {
            min-width: 56px;
            min-height: 26px;
            max-width: calc(100vw - 16px);
            padding: 4px 8px;
            gap: 5px;
            font-size: {$mobileFontSize}px;
            border-radius: min({$radius}px, 8px);
        }

        #goofps .goofps-dot {
            width: 5px;
            height: 5px;
            flex-basis: 5px;
        }
    }

    @media print {
        #goofps {
            display: none !important;
        }
    }
</style>
CSS;
    }

    public static function renderFooter($archive = null)
    {
        $config = self::getConfig();

        $showDot =
            self::option($config, 'showDot', 'on') === 'on';

        $updateInterval = self::number(
            self::option($config, 'updateInterval', '500'),
            250,
            1000,
            500
        );

        $dot = $showDot
            ? '<span class="goofps-dot" aria-hidden="true"></span>'
            : '';

        echo <<<HTML
<div
    id="goofps"
    role="status"
    aria-label="实时帧率"
    aria-live="off"
>
    {$dot}
    <span class="goofps-label">FPS</span>
    <span class="goofps-value">--</span>
</div>

<script id="goofps-script">
(function (window, document) {
    'use strict';

    if (window.__GoofpsInitialized) {
        return;
    }

    window.__GoofpsInitialized = true;

    var updateInterval = {$updateInterval};
    var requestId = 0;
    var frameCount = 0;
    var lastUpdate = 0;
    var running = false;

    function getRoot() {
        return document.getElementById('goofps');
    }

    function updateValue(fps) {
        var root = getRoot();

        if (!root) {
            return;
        }

        var value = root.querySelector('.goofps-value');

        if (value) {
            value.textContent = String(fps);
        }

        root.setAttribute(
            'aria-label',
            '实时帧率 ' + fps + ' FPS'
        );
    }

    function measure(timestamp) {
        if (!running) {
            return;
        }

        if (!lastUpdate) {
            lastUpdate = timestamp;
        }

        frameCount += 1;

        var elapsed = timestamp - lastUpdate;

        if (elapsed >= updateInterval) {
            var fps = Math.round(frameCount * 1000 / elapsed);

            fps = Math.max(0, Math.min(fps, 999));

            updateValue(fps);

            frameCount = 0;
            lastUpdate = timestamp;
        }

        requestId = window.requestAnimationFrame(measure);
    }

    function start() {
        if (running || document.hidden) {
            return;
        }

        running = true;
        frameCount = 0;
        lastUpdate = 0;
        requestId = window.requestAnimationFrame(measure);
    }

    function stop() {
        running = false;

        if (requestId) {
            window.cancelAnimationFrame(requestId);
            requestId = 0;
        }
    }

    function handleVisibility() {
        if (document.hidden) {
            stop();
        } else {
            start();
        }
    }

    document.addEventListener(
        'visibilitychange',
        handleVisibility,
        false
    );

    window.addEventListener(
        'pagehide',
        stop,
        false
    );

    window.addEventListener(
        'pageshow',
        start,
        false
    );

    if (document.readyState === 'loading') {
        document.addEventListener(
            'DOMContentLoaded',
            start,
            { once: true }
        );
    } else {
        start();
    }
})(window, document);
</script>
HTML;
    }

    private static function getConfig()
    {
        return Options::alloc()->plugin('Goofps');
    }

    private static function option($config, $name, $default)
    {
        if (
            isset($config->{$name})
            && $config->{$name} !== ''
            && $config->{$name} !== null
        ) {
            return (string) $config->{$name};
        }

        return (string) $default;
    }

    private static function number($value, $min, $max, $default)
    {
        if (!is_numeric($value)) {
            return $default;
        }

        $value = (int) $value;

        if ($value < $min) {
            return $min;
        }

        if ($value > $max) {
            return $max;
        }

        return $value;
    }

    private static function getAccentColors($name)
    {
        $colors = [
            'pink' => [
                '#d96c93',
                '#f2a6c1',
            ],
            'blue' => [
                '#4d8fbd',
                '#8bc8ee',
            ],
            'green' => [
                '#4f9b76',
                '#8bd4aa',
            ],
            'purple' => [
                '#8068b1',
                '#baa7e8',
            ],
            'orange' => [
                '#c77b43',
                '#efb27f',
            ],
            'theme' => [
                'var(--themecolor, #d96c93)',
                'var(--themecolor, #f2a6c1)',
            ],
        ];

        return isset($colors[$name])
            ? $colors[$name]
            : $colors['pink'];
    }

    private static function getBackgroundColors($name)
    {
        $colors = [
            'theme' => [
                'color-mix(in srgb, var(--card-color, #ffffff) 88%, transparent)',
                'color-mix(in srgb, var(--card-color, #222426) 88%, transparent)',
            ],
            'pink' => [
                'rgba(255, 240, 246, .88)',
                'rgba(55, 36, 44, .88)',
            ],
            'blue' => [
                'rgba(238, 248, 255, .88)',
                'rgba(31, 44, 54, .88)',
            ],
            'green' => [
                'rgba(239, 250, 244, .88)',
                'rgba(32, 49, 41, .88)',
            ],
            'neutral' => [
                'rgba(255, 255, 255, .84)',
                'rgba(28, 30, 33, .86)',
            ],
            'transparent' => [
                'rgba(255, 255, 255, .56)',
                'rgba(25, 27, 29, .58)',
            ],
        ];

        return isset($colors[$name])
            ? $colors[$name]
            : $colors['theme'];
    }
}